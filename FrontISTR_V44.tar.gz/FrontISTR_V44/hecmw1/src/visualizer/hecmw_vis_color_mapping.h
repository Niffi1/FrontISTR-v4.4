#ifndef HECMW_VIS_COLOR_MAPPING_H_INCLUDED
#define HECMW_VIS_COLOR_MAPPING_H_INCLUDED

void value_to_rgb(double value, double color[3], double mincolor, double maxcolor, int color_mapping_style,
		double *interval_point, int interval_mapping_num, int color_system_type);

#endif /* HECMW_VIS_COLOR_MAPPING_H_INCLUDED */













