/*=====================================================================*
 *                                                                     *
 *   Software Name : HEC-MW Library for PC-cluster                     *
 *         Version : 2.7                                               *
 *                                                                     *
 *     Last Update : 2006/06/01                                        *
 *        Category : I/O and Utility                                   *
 *                                                                     *
 *            Written by Kazuaki Sakane (RIST)                         *
 *                                                                     *
 *     Contact address :  IIS,The University of Tokyo RSS21 project    *
 *                                                                     *
 *     "Structural Analysis System for General-purpose Coupling        *
 *      Simulations Using High End Computing Middleware (HEC-MW)"      *
 *                                                                     *
 *=====================================================================*/



#ifndef HECMW_DIST_FREE_INCLUDED
#define HECMW_DIST_FREE_INCLUDED

#include "hecmw_struct.h"


extern void HECMW_dist_clean(struct hecmwST_local_mesh *mesh);


extern void HECMW_dist_free(struct hecmwST_local_mesh *mesh);

#endif
